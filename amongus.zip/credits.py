import pygame

# Initialize pygame
pygame.init()

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Set up screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Credits")

# Function to display credits
def show_credits():
    running = True
    font = pygame.font.SysFont("Arial", 30)
    credit_lines = [
        "Version 1.0.3",
        "Patch Notes:",
        "- File search improved for better efficiency.",
        "- Added randomized file selection when duplicates are found.",
        "- Improved error handling and user feedback.",
        "- Streamlined the credits display process.",
        "- Thank you for playing Tasks Among Us!",
        "InnovaDev Community Discord",
        "Thanks for playing!",
    ]
    
    while running:
        screen.fill(BLACK)

        # Display credits
        for i, line in enumerate(credit_lines):
            text_surface = font.render(line, True, WHITE)
            screen.blit(
                text_surface,
                (SCREEN_WIDTH // 2 - text_surface.get_width() // 2, 200 + i * 40)
            )

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        pygame.display.flip()
        pygame.time.Clock().tick(60)

    pygame.quit()

# Run the credits screen
show_credits()
